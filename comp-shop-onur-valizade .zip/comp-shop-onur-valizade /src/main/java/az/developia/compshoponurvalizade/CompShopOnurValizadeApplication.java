package az.developia.compshoponurvalizade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompShopOnurValizadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompShopOnurValizadeApplication.class, args);
	}

}
